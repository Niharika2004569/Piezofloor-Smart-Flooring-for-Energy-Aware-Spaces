import serial
import time

data = serial.Serial(
                  'COM3',
                  baudrate = 9600,
                  parity=serial.PARITY_NONE,
                  stopbits=serial.STOPBITS_ONE,
                  bytesize=serial.EIGHTBITS,                  
                  timeout=1
                  )
def ReadData():
    while True:
        d = data.readline()
        d = d.decode('utf-8', 'ignore')
        d = d.replace(' ', '')
        d = d.replace('\r\n', '')
        d = d.split(',')
        if len(d) == 3:
            print(d)
            break
        time.sleep(1)
    return d