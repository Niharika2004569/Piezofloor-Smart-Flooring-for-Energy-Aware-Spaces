from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import random
import time
from database import *
from models import User
# from test import PredictPower

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production

# Initialize database
init_db()

# Simulate serial data (replace with your actual serial communication)
def simulate_serial_data():
    from serial_test import ReadData
    dt = ReadData()
    voltage = float(dt[0])
    step_count = float(dt[1])
    power = PredictPower(voltage, step_count)
    return voltage, step_count, power

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.verify_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    """User registration"""
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']
    
    if User.create_user(username, email, password):
        return jsonify({'success': True, 'message': 'Registration successful!'})
    else:
        return jsonify({'success': False, 'message': 'Username or email already exists!'})

@app.route('/dashboard')
def dashboard():
    """Dashboard with real-time graphs"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/api/power-data')
def get_power_data():
    """API endpoint to get power data for graphs"""
    data = get_recent_power_data(20)
    result = {
        'voltage': [row['voltage'] for row in data],
        'step_count': [row['step_count'] for row in data],
        'power': [row['power'] for row in data],
        'timestamps': [row['timestamp'] for row in data]
    }
    return jsonify(result)

@app.route('/api/update-data')
def update_data():
    """API endpoint to simulate new data (replace with your serial data)"""
    voltage, step_count, power = simulate_serial_data()
    insert_power_data(voltage, step_count, power)
    return jsonify({
        'voltage': voltage,
        'step_count': step_count,
        'power': power
    })

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    """Power prediction page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    prediction = None
    if request.method == 'POST':
        try:
            voltage = float(request.form['voltage'])
            step_count = int(request.form['step_count'])
            prediction = PredictPower(voltage, step_count)
        except ValueError:
            prediction = "Invalid input"
    
    return render_template('predict.html', prediction=prediction)

@app.route('/rewards')
def rewards():
    """Power rewards in rupees"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get power rewards data
    rewards_data = get_power_rewards_rupees()
    
    return render_template('rewards.html', rewards=rewards_data)

@app.route('/api/power-rewards')
def get_power_rewards_api():
    """API endpoint for power rewards in rupees"""
    rewards_data = get_power_rewards_rupees()
    
    return jsonify({
        'total_power': float(rewards_data['total_power']),
        'total_entries': rewards_data['total_entries'],
        'total_rupees': float(rewards_data['total_rupees'])
    })

import re
from datetime import datetime

# Add this function to handle chatbot queries
def process_chatbot_query(message):
    """Process natural language queries and return responses"""
    message = message.lower().strip()
    
    # Today's stats
    if any(word in message for word in ['today', "today's", 'todays']):
        stats = get_today_stats()
        if stats['total_entries'] == 0:
            return "No data recorded today yet."
        
        response = f"📊 **Today's Statistics:**\n\n"
        response += f"• 🔋 Total Voltage: {stats['total_voltage']:.2f} V\n"
        response += f"• 👣 Total Step Count: {stats['total_steps']:,}\n"
        response += f"• ⚡ Total Power: {stats['total_power']:.2f} W\n"
        response += f"• 💰 Total Rewards: ₹{stats['total_rewards']:.2f}\n"
        response += f"• 📈 Data Entries: {stats['total_entries']}"
        return response
    
    # Yesterday's stats
    elif any(word in message for word in ['yesterday', "yesterday's", 'yesterdays']):
        stats = get_yesterday_stats()
        if stats['total_power'] == 0:
            return "No data recorded for yesterday."
        
        response = f"📊 **Yesterday's Statistics:**\n\n"
        response += f"• 🔋 Total Voltage: {stats['total_voltage']:.2f} V\n"
        response += f"• 👣 Total Step Count: {stats['total_steps']:,}\n"
        response += f"• ⚡ Total Power: {stats['total_power']:.2f} W\n"
        response += f"• 💰 Total Rewards: ₹{stats['total_rewards']:.2f}"
        return response
    
    # Week stats
    elif any(word in message for word in ['week', 'weekly', 'this week']):
        stats = get_week_stats()
        if stats['total_power'] == 0:
            return "No data recorded this week yet."
        
        response = f"📊 **This Week's Statistics:**\n\n"
        response += f"• 🔋 Total Voltage: {stats['total_voltage']:.2f} V\n"
        response += f"• 👣 Total Step Count: {stats['total_steps']:,}\n"
        response += f"• ⚡ Total Power: {stats['total_power']:.2f} W\n"
        response += f"• 💰 Total Rewards: ₹{stats['total_rewards']:.2f}"
        return response
    
    # All time stats
    elif any(word in message for word in ['all time', 'total', 'overall', 'all-time']):
        stats = get_all_time_stats()
        if stats['total_power'] == 0:
            return "No data recorded yet."
        
        response = f"📊 **All-Time Statistics:**\n\n"
        response += f"• 🔋 Total Voltage: {stats['total_voltage']:.2f} V\n"
        response += f"• 👣 Total Step Count: {stats['total_steps']:,}\n"
        response += f"• ⚡ Total Power: {stats['total_power']:.2f} W\n"
        response += f"• 💰 Total Rewards: ₹{stats['total_rewards']:.2f}"
        return response
    
    # Rewards specific
    elif any(word in message for word in ['reward', 'rewards', 'rupees', 'money', 'earning']):
        stats = get_today_stats()
        all_time_stats = get_all_time_stats()
        
        response = f"💰 **Rewards Information:**\n\n"
        response += f"**Today:**\n"
        response += f"• Power: {stats['total_power']:.2f} W\n"
        response += f"• Rewards: ₹{stats['total_rewards']:.2f}\n\n"
        response += f"**All Time:**\n"
        response += f"• Total Power: {all_time_stats['total_power']:.2f} W\n"
        response += f"• Total Rewards: ₹{all_time_stats['total_rewards']:.2f}\n\n"
        response += f"💡 *Rate: ₹10 per power unit*"
        return response
    
    # Power specific
    elif any(word in message for word in ['power', 'electricity', 'energy']):
        stats = get_today_stats()
        peak = get_peak_stats()
        
        response = f"⚡ **Power Statistics:**\n\n"
        response += f"**Today:**\n"
        response += f"• Total Power: {stats['total_power']:.2f} W\n"
        response += f"• Rewards: ₹{stats['total_rewards']:.2f}\n\n"
        response += f"**Peak Performance:**\n"
        response += f"• Highest Power: {peak['peak_power']:.2f} W"
        return response
    
    # Step count specific
    elif any(word in message for word in ['step', 'steps', 'walking', 'movement']):
        stats = get_today_stats()
        peak = get_peak_stats()
        
        response = f"👣 **Step Count Statistics:**\n\n"
        response += f"**Today:**\n"
        response += f"• Total Steps: {stats['total_steps']:,}\n\n"
        response += f"**Peak Performance:**\n"
        response += f"• Highest Step Count: {peak['peak_steps']:,}"
        return response
    
    # Voltage specific
    elif any(word in message for word in ['voltage', 'volt', 'battery']):
        stats = get_today_stats()
        peak = get_peak_stats()
        
        response = f"🔋 **Voltage Statistics:**\n\n"
        response += f"**Today:**\n"
        response += f"• Total Voltage: {stats['total_voltage']:.2f} V\n\n"
        response += f"**Peak Performance:**\n"
        response += f"• Highest Voltage: {peak['peak_voltage']:.2f} V"
        return response
    
    # Help
    elif any(word in message for word in ['help', 'what can you do', 'commands']):
        response = "🤖 **I can help you with:**\n\n"
        response += "• 📊 **Today's stats** - Ask about today's data\n"
        response += "• 📈 **Yesterday's stats** - Yesterday's performance\n"
        response += "• 🗓️ **Weekly stats** - This week's totals\n"
        response += "• ⏳ **All-time stats** - Overall performance\n"
        response += "• 💰 **Rewards** - Earnings information\n"
        response += "• ⚡ **Power** - Power generation details\n"
        response += "• 👣 **Steps** - Step count information\n"
        response += "• 🔋 **Voltage** - Voltage statistics\n\n"
        response += "💡 *Try asking: 'What are today's stats?' or 'How much rewards did I earn?'*"
        return response
    
    # Default response
    else:
        return "🤖 I'm here to help you with your power monitoring data! Try asking:\n\n• \"What are today's statistics?\"\n• \"How much rewards did I earn?\"\n• \"Show me power generation details\"\n• \"What can you help me with?\""

# Add chatbot route
@app.route('/chatbot')
def chatbot():
    """Chatbot page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('chatbot.html')

@app.route('/api/chatbot', methods=['POST'])
def chatbot_api():
    """Chatbot API endpoint"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'error': 'No message provided'}), 400
    
    # Process the query and get response
    response = process_chatbot_query(message)
    
    return jsonify({
        'response': response,
        'timestamp': datetime.now().strftime('%H:%M:%S')
    })

from datetime import datetime, timedelta

@app.route('/heatmap')
def heatmap():
    """Heatmap visualization page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get heatmap data
    daily_data = get_heatmap_data(30)  # Last 30 days
    hourly_data = get_hourly_heatmap_data(7)  # Last 7 days hourly
    
    return render_template('heatmap.html', 
                         daily_data=daily_data,
                         hourly_data=hourly_data)

@app.route('/api/heatmap/daily')
def get_daily_heatmap_api():
    """API endpoint for daily heatmap data"""
    days = request.args.get('days', 30, type=int)
    data = get_heatmap_data(days)
    
    # Format data for frontend
    formatted_data = []
    for row in data:
        formatted_data.append({
            'date': row['date'],
            'power': float(row['daily_power']),
            'steps': row['daily_steps'],
            'voltage': float(row['daily_voltage']),
            'entries': row['entries_count'],
            'rewards': float(row['daily_power']) * 10
        })
    
    return jsonify(formatted_data)

@app.route('/api/heatmap/hourly')
def get_hourly_heatmap_api():
    """API endpoint for hourly heatmap data"""
    days = request.args.get('days', 7, type=int)
    data = get_hourly_heatmap_data(days)
    
    # Format data for frontend
    formatted_data = []
    for row in data:
        formatted_data.append({
            'date': row['date'],
            'hour': int(row['hour']),
            'power': float(row['hourly_power']),
            'entries': row['entries_count']
        })
    
    return jsonify(formatted_data)
    
@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)