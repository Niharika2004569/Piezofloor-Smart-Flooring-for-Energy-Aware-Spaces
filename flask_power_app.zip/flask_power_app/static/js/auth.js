document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const showRegister = document.getElementById('showRegister');
    const showLogin = document.getElementById('showLogin');
    const loginCard = document.querySelector('.auth-card:not(.hidden)');
    const registerCard = document.getElementById('registerCard');
    const passwordInput = document.getElementById('regPassword');
    const passwordStrength = document.getElementById('passwordStrength');

    // Initialize password strength if exists
    if (passwordInput && passwordStrength) {
        passwordInput.addEventListener('input', updatePasswordStrength);
    }

    // Toggle between login and register forms with animation
    showRegister?.addEventListener('click', function(e) {
        e.preventDefault();
        switchForms(loginCard, registerCard);
    });

    showLogin?.addEventListener('click', function(e) {
        e.preventDefault();
        switchForms(registerCard, loginCard);
    });

    function switchForms(hideForm, showForm) {
        // Add slide out animation
        hideForm.style.animation = 'cardSlideOut 0.4s ease-in forwards';
        
        setTimeout(() => {
            hideForm.classList.add('hidden');
            showForm.classList.remove('hidden');
            
            // Add slide in animation
            showForm.style.animation = 'cardSlideIn 0.4s ease-out';
            
            // Reset animation after completion
            setTimeout(() => {
                showForm.style.animation = '';
                hideForm.style.animation = '';
            }, 400);
        }, 200);
    }

    // Add CSS for slide animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes cardSlideOut {
            from {
                opacity: 1;
                transform: translateX(0) scale(1);
            }
            to {
                opacity: 0;
                transform: translateX(-50px) scale(0.95);
            }
        }
        
        @keyframes cardSlideIn {
            from {
                opacity: 0;
                transform: translateX(50px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateX(0) scale(1);
            }
        }
    `;
    document.head.appendChild(style);

    // Handle login form submission
    loginForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        handleFormSubmission(this, '/login', 'Signing in...');
    });

    // Handle register form submission
    registerForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        handleFormSubmission(this, '/register', 'Creating account...');
    });

    function handleFormSubmission(form, url, loadingText) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        // Show loading state
        submitBtn.innerHTML = `<i class="fas fa-spinner"></i> ${loadingText}`;
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        const formData = new FormData(form);
        
        fetch(url, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.redirected) {
                // Login success
                showMessage('Login successful! Redirecting...', 'success');
                setTimeout(() => {
                    window.location.href = response.url;
                }, 1000);
            } else if (url === '/register') {
                return response.json();
            } else {
                throw new Error('Invalid credentials');
            }
        })
        .then(data => {
            if (data) {
                if (data.success) {
                    showMessage(data.message, 'success');
                    setTimeout(() => {
                        registerCard.classList.add('hidden');
                        loginCard.classList.remove('hidden');
                        registerForm.reset();
                        resetPasswordStrength();
                    }, 1500);
                } else {
                    throw new Error(data.message);
                }
            }
        })
        .catch(error => {
            showMessage(error.message, 'error');
        })
        .finally(() => {
            // Reset button state
            submitBtn.innerHTML = originalText;
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
        });
    }

    function showMessage(text, type) {
        // Remove existing messages
        const existingMessage = document.querySelector('.message');
        if (existingMessage) {
            existingMessage.remove();
        }

        const message = document.createElement('div');
        message.className = `message ${type}`;
        message.textContent = text;
        
        const currentCard = document.querySelector('.auth-card:not(.hidden)');
        currentCard.insertBefore(message, currentCard.querySelector('.auth-form'));
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (message.parentNode) {
                message.remove();
            }
        }, 5000);
    }

    function updatePasswordStrength() {
        if (!passwordStrength) return;
        
        const password = passwordInput.value;
        const strengthBar = passwordStrength.querySelector('.strength-bar');
        
        let strength = 0;
        let feedback = '';
        
        if (password.length >= 8) strength += 1;
        if (/[A-Z]/.test(password)) strength += 1;
        if (/[0-9]/.test(password)) strength += 1;
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;
        
        // Update strength bar
        strengthBar.className = 'strength-bar';
        if (password.length === 0) {
            strengthBar.style.width = '0%';
            strengthBar.style.backgroundColor = '';
        } else if (strength <= 1) {
            strengthBar.classList.add('strength-weak');
            strengthBar.style.backgroundColor = '#ef4444';
        } else if (strength <= 2) {
            strengthBar.classList.add('strength-medium');
            strengthBar.style.backgroundColor = '#f59e0b';
        } else {
            strengthBar.classList.add('strength-strong');
            strengthBar.style.backgroundColor = '#10b981';
        }
    }

    function resetPasswordStrength() {
        if (passwordStrength) {
            const strengthBar = passwordStrength.querySelector('.strength-bar');
            strengthBar.className = 'strength-bar';
            strengthBar.style.width = '0%';
            strengthBar.style.backgroundColor = '';
        }
    }

    // Add input focus effects
    const inputs = document.querySelectorAll('.form-group input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });
    });

    // Add enter key support
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const activeForm = document.querySelector('.auth-card:not(.hidden) .auth-form');
            if (activeForm) {
                activeForm.dispatchEvent(new Event('submit'));
            }
        }
    });
});