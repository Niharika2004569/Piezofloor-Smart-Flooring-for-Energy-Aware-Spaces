let voltageChart, stepsChart, powerChart;
let voltageData = [];
let stepsData = [];
let powerData = [];
let timestamps = [];

document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    updateCurrentValues();
    loadHistoricalData();
    
    // Update data every second
    setInterval(updateData, 1000);
});

function initializeCharts() {
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
            duration: 500
        },
        scales: {
            x: {
                display: true,
                title: {
                    display: true,
                    text: 'Time'
                }
            },
            y: {
                display: true,
                title: {
                    display: true,
                    text: 'Value'
                }
            }
        },
        plugins: {
            legend: {
                display: false
            }
        }
    };

    // Voltage Chart
    const voltageCtx = document.getElementById('voltageChart').getContext('2d');
    voltageChart = new Chart(voltageCtx, {
        type: 'line',
        data: {
            labels: timestamps,
            datasets: [{
                label: 'Voltage (V)',
                data: voltageData,
                borderColor: '#ff6b6b',
                backgroundColor: 'rgba(255, 107, 107, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: chartOptions
    });

    // Steps Chart
    const stepsCtx = document.getElementById('stepsChart').getContext('2d');
    stepsChart = new Chart(stepsCtx, {
        type: 'line',
        data: {
            labels: timestamps,
            datasets: [{
                label: 'Step Count',
                data: stepsData,
                borderColor: '#4ecdc4',
                backgroundColor: 'rgba(78, 205, 196, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: chartOptions
    });

    // Power Chart
    const powerCtx = document.getElementById('powerChart').getContext('2d');
    powerChart = new Chart(powerCtx, {
        type: 'line',
        data: {
            labels: timestamps,
            datasets: [{
                label: 'Power (W)',
                data: powerData,
                borderColor: '#45b7d1',
                backgroundColor: 'rgba(69, 183, 209, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: chartOptions
    });
}

function loadHistoricalData() {
    fetch('/api/power-data')
        .then(response => response.json())
        .then(data => {
            voltageData = data.voltage || [];
            stepsData = data.step_count || [];
            powerData = data.power || [];
            timestamps = data.timestamps || Array.from({length: voltageData.length}, (_, i) => `Point ${i + 1}`);
            
            updateCharts();
        })
        .catch(error => console.error('Error loading historical data:', error));
}

function updateData() {
    fetch('/api/update-data')
        .then(response => response.json())
        .then(newData => {
            // Update current values display
            document.getElementById('currentVoltage').textContent = newData.voltage;
            document.getElementById('currentSteps').textContent = newData.step_count;
            document.getElementById('currentPower').textContent = newData.power;
            
            // Add new data to arrays
            voltageData.push(newData.voltage);
            stepsData.push(newData.step_count);
            powerData.push(newData.power);
            timestamps.push(new Date().toLocaleTimeString());
            
            // Keep only last 20 values
            if (voltageData.length > 20) {
                voltageData.shift();
                stepsData.shift();
                powerData.shift();
                timestamps.shift();
            }
            
            updateCharts();
        })
        .catch(error => console.error('Error updating data:', error));
}

function updateCharts() {
    voltageChart.data.labels = timestamps;
    voltageChart.data.datasets[0].data = voltageData;
    voltageChart.update('none');
    
    stepsChart.data.labels = timestamps;
    stepsChart.data.datasets[0].data = stepsData;
    stepsChart.update('none');
    
    powerChart.data.labels = timestamps;
    powerChart.data.datasets[0].data = powerData;
    powerChart.update('none');
}

function updateCurrentValues() {
    // Initial update of current values
    if (voltageData.length > 0) {
        document.getElementById('currentVoltage').textContent = voltageData[voltageData.length - 1];
        document.getElementById('currentSteps').textContent = stepsData[stepsData.length - 1];
        document.getElementById('currentPower').textContent = powerData[powerData.length - 1];
    }
}