class PowerHeatmap {
    constructor() {
        this.dailyData = [];
        this.hourlyData = [];
        this.currentDataType = 'power';
        this.currentDays = 30;
        this.currentView = 'daily';
        
        this.colorScales = {
            power: d3.scaleSequential(d3.interpolateOranges),
            rewards: d3.scaleSequential(d3.interpolateGreens),
            steps: d3.scaleSequential(d3.interpolateBlues),
            voltage: d3.scaleSequential(d3.interpolatePurples)
        };
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.loadDailyData();
    }
    
    setupEventListeners() {
        // Time range change
        document.getElementById('timeRange').addEventListener('change', (e) => {
            this.currentDays = parseInt(e.target.value);
            if (this.currentView === 'daily') {
                this.loadDailyData();
            } else {
                this.loadHourlyData();
            }
        });
        
        // Data type change
        document.getElementById('dataType').addEventListener('change', (e) => {
            this.currentDataType = e.target.value;
            if (this.currentView === 'daily') {
                this.renderDailyHeatmap();
            } else {
                this.renderHourlyHeatmap();
            }
        });
        
        // View type change
        document.getElementById('viewType').addEventListener('change', (e) => {
            this.currentView = e.target.value;
            this.toggleView();
        });
    }
    
    toggleView() {
        const dailySection = document.getElementById('dailyHeatmapSection');
        const hourlySection = document.getElementById('hourlyHeatmapSection');
        
        if (this.currentView === 'daily') {
            dailySection.classList.remove('hidden');
            hourlySection.classList.add('hidden');
            this.loadDailyData();
        } else {
            dailySection.classList.add('hidden');
            hourlySection.classList.remove('hidden');
            this.loadHourlyData();
        }
    }
    
    async loadDailyData() {
        try {
            const response = await fetch(`/api/heatmap/daily?days=${this.currentDays}`);
            this.dailyData = await response.json();
            this.renderDailyHeatmap();
            this.updateStatistics();
        } catch (error) {
            console.error('Error loading daily data:', error);
        }
    }
    
    async loadHourlyData() {
        try {
            const response = await fetch(`/api/heatmap/hourly?days=${this.currentDays}`);
            this.hourlyData = await response.json();
            this.renderHourlyHeatmap();
        } catch (error) {
            console.error('Error loading hourly data:', error);
        }
    }
    
    renderDailyHeatmap() {
        const container = document.getElementById('calendarHeatmap');
        container.innerHTML = '';
        
        if (this.dailyData.length === 0) {
            container.innerHTML = '<div class="no-data">No data available for the selected period</div>';
            return;
        }
        
        // Prepare data
        const dataMap = new Map();
        this.dailyData.forEach(d => {
            dataMap.set(d.date, d[this.currentDataType]);
        });
        
        // Get date range
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - this.currentDays + 1);
        
        // Create calendar structure
        const calendar = document.createElement('div');
        calendar.className = 'calendar-grid';
        
        // Add month headers
        const months = this.getMonthsInRange(startDate, endDate);
        months.forEach(month => {
            const monthHeader = document.createElement('div');
            monthHeader.className = 'month-header';
            monthHeader.textContent = month;
            calendar.appendChild(monthHeader);
        });
        
        // Add day cells
        const currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            const dateStr = currentDate.toISOString().split('T')[0];
            const value = dataMap.get(dateStr) || 0;
            
            const dayCell = document.createElement('div');
            dayCell.className = 'day-cell';
            dayCell.setAttribute('data-date', dateStr);
            dayCell.setAttribute('data-value', value);
            
            // Set color based on value
            const color = this.getColorForValue(value);
            dayCell.style.backgroundColor = color;
            
            // Add tooltip
            dayCell.title = `${dateStr}\n${this.getDataTypeLabel()}: ${this.formatValue(value)}`;
            
            calendar.appendChild(dayCell);
            
            currentDate.setDate(currentDate.getDate() + 1);
        }
        
        container.appendChild(calendar);
    }
    
    renderHourlyHeatmap() {
        const container = document.getElementById('hourlyHeatmap');
        container.innerHTML = '';
        
        if (this.hourlyData.length === 0) {
            container.innerHTML = '<div class="no-data">No hourly data available</div>';
            return;
        }
        
        // Group data by date
        const dataByDate = new Map();
        this.hourlyData.forEach(d => {
            if (!dataByDate.has(d.date)) {
                dataByDate.set(d.date, new Array(24).fill(0));
            }
            dataByDate.get(d.date)[d.hour] = d.power;
        });
        
        // Get unique dates
        const dates = Array.from(dataByDate.keys()).sort();
        
        // Create heatmap grid
        const grid = document.createElement('div');
        grid.className = 'hourly-grid';
        
        // Add hour labels
        const hourLabels = document.createElement('div');
        hourLabels.className = 'hour-labels';
        for (let hour = 0; hour < 24; hour++) {
            const label = document.createElement('div');
            label.className = 'hour-label';
            label.textContent = `${hour.toString().padStart(2, '0')}:00`;
            hourLabels.appendChild(label);
        }
        grid.appendChild(hourLabels);
        
        // Add data cells
        dates.forEach(date => {
            const dateRow = document.createElement('div');
            dateRow.className = 'date-row';
            
            const dateLabel = document.createElement('div');
            dateLabel.className = 'date-label';
            dateLabel.textContent = new Date(date).toLocaleDateString();
            dateRow.appendChild(dateLabel);
            
            const hourCells = document.createElement('div');
            hourCells.className = 'hour-cells';
            
            const hourlyData = dataByDate.get(date);
            for (let hour = 0; hour < 24; hour++) {
                const value = hourlyData[hour];
                const cell = document.createElement('div');
                cell.className = 'hour-cell';
                cell.style.backgroundColor = this.getColorForValue(value);
                cell.title = `${date} ${hour.toString().padStart(2, '0')}:00\nPower: ${value.toFixed(2)} W`;
                hourCells.appendChild(cell);
            }
            
            dateRow.appendChild(hourCells);
            grid.appendChild(dateRow);
        });
        
        container.appendChild(grid);
    }
    
    getColorForValue(value) {
        const maxValue = this.getMaxValue();
        if (maxValue === 0) return '#ebedf0'; // No data color
        
        const normalizedValue = value / maxValue;
        return this.colorScales[this.currentDataType](normalizedValue);
    }
    
    getMaxValue() {
        if (this.currentView === 'daily') {
            return Math.max(...this.dailyData.map(d => d[this.currentDataType]), 1);
        } else {
            return Math.max(...this.hourlyData.map(d => d.power), 1);
        }
    }
    
    getDataTypeLabel() {
        const labels = {
            power: 'Power',
            rewards: 'Rewards',
            steps: 'Steps',
            voltage: 'Voltage'
        };
        return labels[this.currentDataType];
    }
    
    formatValue(value) {
        if (this.currentDataType === 'rewards') {
            return `₹${value.toFixed(2)}`;
        } else if (this.currentDataType === 'steps') {
            return value.toLocaleString();
        } else {
            return value.toFixed(2);
        }
    }
    
    getMonthsInRange(startDate, endDate) {
        const months = [];
        const current = new Date(startDate);
        
        while (current <= endDate) {
            const monthYear = current.toLocaleDateString('en', { month: 'short', year: 'numeric' });
            if (!months.includes(monthYear)) {
                months.push(monthYear);
            }
            current.setMonth(current.getMonth() + 1);
        }
        
        return months;
    }
    
    updateStatistics() {
        if (this.dailyData.length === 0) return;
        
        const totalPower = this.dailyData.reduce((sum, day) => sum + day.power, 0);
        const totalRewards = this.dailyData.reduce((sum, day) => sum + day.rewards, 0);
        const avgDailyPower = totalPower / this.dailyData.length;
        
        document.getElementById('totalDays').textContent = this.dailyData.length;
        document.getElementById('totalPower').textContent = totalPower.toFixed(2);
        document.getElementById('totalRewards').textContent = `₹${totalRewards.toFixed(2)}`;
        document.getElementById('avgDaily').textContent = avgDailyPower.toFixed(2);
    }
}

// Initialize heatmap when page loads
document.addEventListener('DOMContentLoaded', function() {
    new PowerHeatmap();
});