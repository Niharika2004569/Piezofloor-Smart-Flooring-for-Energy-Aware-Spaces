import sqlite3
import os
from datetime import datetime

def init_db():
    """Initialize the database with required tables"""
    conn = sqlite3.connect('power_data.db')
    cursor = conn.cursor()
    
    # Users table for login/registration
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Power data table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS power_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            voltage REAL NOT NULL,
            step_count INTEGER NOT NULL,
            power REAL NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect('power_data.db')
    conn.row_factory = sqlite3.Row
    return conn

def insert_power_data(voltage, step_count, power):
    """Insert new power data into database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO power_data (voltage, step_count, power) VALUES (?, ?, ?)',
        (voltage, step_count, power)
    )
    conn.commit()
    conn.close()

def get_recent_power_data(limit=20):
    """Get recent power data for graphing"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT voltage, step_count, power, timestamp 
        FROM power_data 
        ORDER BY timestamp DESC 
        LIMIT ?
    ''', (limit,))
    data = cursor.fetchall()
    conn.close()
    return data[::-1]  # Reverse to get chronological order

def get_power_rewards_rupees():
    """Calculate total power and rewards in rupees (₹10 per power)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            COALESCE(SUM(power), 0) as total_power,
            COUNT(*) as total_entries,
            COALESCE(SUM(power), 0) * 10 as total_rupees
        FROM power_data
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_recent_power_with_rewards(limit=20):
    """Get recent power data with rupees rewards"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            voltage,
            step_count,
            power,
            power * 10 as rupees,
            timestamp
        FROM power_data 
        ORDER BY timestamp DESC 
        LIMIT ?
    ''', (limit,))
    
    data = cursor.fetchall()
    conn.close()
    return data[::-1]  # Reverse to get chronological order

def get_today_stats():
    """Get today's total step counts, voltage, power and rewards"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            COALESCE(SUM(step_count), 0) as total_steps,
            COALESCE(SUM(voltage), 0) as total_voltage,
            COALESCE(SUM(power), 0) as total_power,
            COUNT(*) as total_entries,
            COALESCE(SUM(power), 0) * 10 as total_rewards
        FROM power_data 
        WHERE DATE(timestamp) = DATE('now')
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_yesterday_stats():
    """Get yesterday's stats"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            COALESCE(SUM(step_count), 0) as total_steps,
            COALESCE(SUM(voltage), 0) as total_voltage,
            COALESCE(SUM(power), 0) as total_power,
            COALESCE(SUM(power), 0) * 10 as total_rewards
        FROM power_data 
        WHERE DATE(timestamp) = DATE('now', '-1 day')
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_week_stats():
    """Get this week's stats"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            COALESCE(SUM(step_count), 0) as total_steps,
            COALESCE(SUM(voltage), 0) as total_voltage,
            COALESCE(SUM(power), 0) as total_power,
            COALESCE(SUM(power), 0) * 10 as total_rewards
        FROM power_data 
        WHERE strftime('%Y-%W', timestamp) = strftime('%Y-%W', 'now')
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_all_time_stats():
    """Get all-time stats"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            COALESCE(SUM(step_count), 0) as total_steps,
            COALESCE(SUM(voltage), 0) as total_voltage,
            COALESCE(SUM(power), 0) as total_power,
            COALESCE(SUM(power), 0) * 10 as total_rewards
        FROM power_data
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_peak_stats():
    """Get peak values"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            MAX(step_count) as peak_steps,
            MAX(voltage) as peak_voltage,
            MAX(power) as peak_power
        FROM power_data
    ''')
    
    result = cursor.fetchone()
    conn.close()
    return result

def get_heatmap_data(days=30):
    """Get data for heatmap - daily power generation for last N days"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            DATE(timestamp) as date,
            SUM(power) as daily_power,
            SUM(step_count) as daily_steps,
            SUM(voltage) as daily_voltage,
            COUNT(*) as entries_count
        FROM power_data
        WHERE timestamp >= date('now', ?)
        GROUP BY DATE(timestamp)
        ORDER BY date
    ''', (f'-{days} days',))
    
    results = cursor.fetchall()
    conn.close()
    return results

def get_hourly_heatmap_data(days=7):
    """Get hourly data for detailed heatmap"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            DATE(timestamp) as date,
            strftime('%H', timestamp) as hour,
            SUM(power) as hourly_power,
            COUNT(*) as entries_count
        FROM power_data
        WHERE timestamp >= date('now', ?)
        GROUP BY DATE(timestamp), strftime('%H', timestamp)
        ORDER BY date, hour
    ''', (f'-{days} days',))
    
    results = cursor.fetchall()
    conn.close()
    return results