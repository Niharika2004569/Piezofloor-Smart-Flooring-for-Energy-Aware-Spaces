# piezo_test.py

import pickle
import numpy as np

# -----------------------------
# Load saved model and scaler
# -----------------------------
with open("best_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

# -----------------------------
# Take user input
# -----------------------------
def PredictPower(stepcount, voltage):
    # -----------------------------
    # Prepare input for prediction
    # -----------------------------
    input_data = np.array([[stepcount, voltage]])
    input_scaled = scaler.transform(input_data)

    # -----------------------------
    # Predict Power Generation
    # -----------------------------
    predicted_power = model.predict(input_scaled)[0]

    print("\n🔋 Predicted Power Generation:")
    print(f"➡️ For Step Count = {stepcount} and Voltage = {voltage} V")
    print(f"✅ Predicted Power = {predicted_power:.4f} Watts")
    return f'{predicted_power:.4f}'
