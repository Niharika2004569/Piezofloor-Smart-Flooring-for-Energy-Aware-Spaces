# piezo_train.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR

# -----------------------------
# Load Dataset
# -----------------------------
df = pd.read_csv("piezo_power_data.csv")

X = df[['stepcount', 'voltage']].values
y = df['power_generation'].values

# -----------------------------
# Split Data
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -----------------------------
# Scale Features
# -----------------------------
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# -----------------------------
# Define Models
# -----------------------------
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42),
    "Gradient Boosting": GradientBoostingRegressor(n_estimators=200, random_state=42),
    "SVR": SVR(kernel='rbf')
}

results = {}

# -----------------------------
# Train & Evaluate Each Model
# -----------------------------
for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    results[name] = {"R2": r2, "RMSE": rmse}
    print(f"{name}: R2 = {r2:.4f}, RMSE = {rmse:.4f}")

# -----------------------------
# Compare Results
# -----------------------------
results_df = pd.DataFrame(results).T
print("\nModel Performance Comparison:\n")
print(results_df)

# -----------------------------
# Find Best Model
# -----------------------------
best_model_name = results_df["R2"].idxmax()
best_model = models[best_model_name]
print(f"\n✅ Best Model: {best_model_name} (R2 = {results_df.loc[best_model_name, 'R2']:.4f})")

# -----------------------------
# Save Best Model & Scaler
# -----------------------------
with open("best_model.pkl", "wb") as f:
    pickle.dump(best_model, f)

with open("scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

print("\n🎯 Model and scaler saved successfully!")

# -----------------------------
# Plot Accuracy Comparison
# -----------------------------
plt.figure(figsize=(8, 5))
plt.bar(results_df.index, results_df["R2"], color=['skyblue', 'lightgreen', 'orange', 'pink'])
plt.ylabel("R² Score")
plt.title("Model Accuracy Comparison")
plt.xticks(rotation=20)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.savefig("model_comparison_accuracy.png")
plt.show()
print("\n📊 Comparison plot saved as 'model_comparison_accuracy.png'")
